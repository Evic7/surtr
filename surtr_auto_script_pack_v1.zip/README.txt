***** SURTR SCRIPT PACK V1 *****

NOTE: This scripts are created by the owner of surtr ** Evander Victor ** and licensed free for all users,Which
means that users can modify or use these scripts for any puropse free of charge.

THIS PACK CONTAINS NINE SCRIPTS

1) alarmer.as : A surtr auto script file that lets you set an
alarm event that performs an action when triggered. 

2) bruteforce.as : A surtr auto script file that performs bruteforce on login pages.

3) extractdashboard.as : A surtr auto script file that log into users site dashboard using provided
username & password, takes a screen shot of the page and also extract and save all text content found 
in it.

4) filewatcher.as : A surtr auto script file that frequently watches files and folders for and alerts the user if
any changes is detected whth option to restore back to previous state.

5) link-downloader.as : A surtr auto script file that monitors your clipboard content for links , if a link is detected
(the user copied a link) prompt the user for a download option.

6) multi-monitor-screenshot-archiver.as : A surtr auto script file that takes and saves screenshot of multiple screens
at once.

7) organizer.as : A surtr auto script file that organizes files in created organized directories.

8) TTS.as : Advanced text to speech script with read file options.

9) windowscreenshot.as : A surtr auto script file that takes screenshot of open windows.



